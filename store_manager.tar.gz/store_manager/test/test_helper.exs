ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(StoreManager.Repo, :manual)
