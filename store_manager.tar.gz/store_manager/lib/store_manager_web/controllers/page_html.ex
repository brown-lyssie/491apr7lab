defmodule StoreManagerWeb.PageHTML do
  use StoreManagerWeb, :html

  embed_templates "page_html/*"
end
