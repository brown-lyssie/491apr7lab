defmodule StoreManagerWeb.Layouts do
  use StoreManagerWeb, :html

  embed_templates "layouts/*"
end
