defmodule StoreManager.Mailer do
  use Swoosh.Mailer, otp_app: :store_manager
end
